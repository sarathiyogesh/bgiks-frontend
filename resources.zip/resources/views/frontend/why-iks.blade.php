@extends('frontend.master')
@section('maincontent')
	<main id="main">
        <section class="small-section bg-white pt-50 pb-50">
        </section>
        <section class="page-section">
            <div class="container relative">
                <div class="row d-flex align-items-center">
                    <div class="col-md-6">
                        <div>
                            <div class="page-title mb-20 wow fadeInDown text-center" data-wow-delay="0.3s" data-wow-duration="1s">Why IKS</div>
                            <div class="section-text black text-center">
                                <p>Coming Soon</p>
                            </div>
                            <!-- <div class="mt-30">
                                <a href="javascript:;" class="btn btn-mod btn-color btn-round btn-small">read more about iks</a>
                            </div> -->
                        </div>
                    </div>

                    <!-- <div class="col-md-6">
                        <div class="img-rounded">
                            <img src="/frontend/images/img-default-05.jpg">
                        </div>
                    </div> -->
                </div>
            </div>
        </section>
        <section class="small-section bg-white pt-40 pb-40">
        </section>
    </main>
@endsection