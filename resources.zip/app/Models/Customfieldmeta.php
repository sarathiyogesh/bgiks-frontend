<?php 
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Auth;
use Session;

class Customfieldmeta extends Model 
{
	protected $table = 'custom_fields_meta';

}