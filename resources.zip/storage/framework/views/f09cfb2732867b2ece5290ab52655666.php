
<?php $__env->startSection('maincontent'); ?>
	<main id="main">
        <section class="small-section bg-white pt-20 pb-20">
        </section>
        <section class="page-section bg-white pb-60">
            <div class="container relative">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-title mb-30">Credentials</h1>

                        <div class="box-one mb-40">
                            <h2 class="hs-line-2 mb-20"><?php echo Helpers::getcontent("section_1_70"); ?></h2>
                            <div class="section-text white">
                                <?php echo Helpers::getcontent("section_1_71"); ?>

                            </div>
                        </div>


                        <h3 class="hs-line-3 mb-10"><?php echo Helpers::getcontent("section_2_72"); ?></h3>

                        <div class="row mt-20 local-scroll">
                            <div class="col-md-4 wow fadeInDown" data-wow-delay="0.3s" data-wow-duration="1s">
                                <a href="#mouwithiksdivision">
                                    <div class="box-two d-flex align-items-center mb-20">
                                        <div class="me-3"><img src="<?php echo Helpers::getsingleimage('section_2_74'); ?>"></div>
                                        <div class="text-center section-text"><?php echo Helpers::getcontent("section_2_73"); ?></div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-md-4 wow fadeInDown" data-wow-delay="0.3s" data-wow-duration="2s">
                                <a href="#mentorswithiks">
                                    <div class="box-two d-flex align-items-center mb-20">
                                        <div class="me-3"><img src="<?php echo Helpers::getsingleimage('section_2_76'); ?>"></div>
                                        <div class="text-center section-text"><?php echo Helpers::getcontent("section_2_75"); ?></div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-md-4 wow fadeInDown" data-wow-delay="0.3s" data-wow-duration="3s">
                                <a href="#expertsiniks">
                                    <div class="box-two d-flex align-items-center mb-20">
                                        <div class="me-3"><img src="<?php echo Helpers::getsingleimage('section_2_78'); ?>"></div>
                                        <div class="text-center section-text"><?php echo Helpers::getcontent("section_2_77"); ?></div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-md-4 wow fadeInDown" data-wow-delay="0.3s" data-wow-duration="3s">
                                <a href="#authorsofbooks">
                                    <div class="box-two d-flex align-items-center mb-20">
                                        <div class="me-3"><img src="<?php echo Helpers::getsingleimage('section_2_80'); ?>"></div>
                                        <div class="text-center section-text"><?php echo Helpers::getcontent("section_2_79"); ?></div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-md-4 wow fadeInDown" data-wow-delay="0.3s" data-wow-duration="3s">
                                <a href="#facultyforfdp">
                                    <div class="box-two d-flex align-items-center mb-20">
                                        <div class="me-3"><img src="<?php echo Helpers::getsingleimage('section_2_82'); ?>"></div>
                                        <div class="text-center section-text"><?php echo Helpers::getcontent("section_2_81"); ?></div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="small-section bg-gray-lighter" id="mouwithiksdivision">
            <div class="container relative">
                <div class="row">
                    <div class="col-md-6">
                        <div class="inner-pad-02">
                            <h4 class="page-title mb-20 wow fadeInDown" data-wow-delay="0.3s" data-wow-duration="1s"><?php echo Helpers::getcontent("section_3_83"); ?></h4>
                            <div class="section-text black">
                                <?php echo Helpers::getcontent("section_3_85"); ?>

                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 mt-xs-20">
                        <div class="img-rounded">
                            <img src="<?php echo Helpers::getsingleimage('section_3_84'); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="small-section" id="mentorswithiks">
            <div class="container relative">
                <div class="row mb-30 d-flex align-items-center">
                    <div class="col-md-12">
                        <div class="page-title color-blue mb-20 wow fadeInDown" data-wow-delay="0.3s" data-wow-duration="1s"><?php echo Helpers::getcontent("section_4_86"); ?></div>
                        <div class="section-text black">
                            <?php echo Helpers::getcontent("section_4_87"); ?>

                        </div>
                    </div>
                </div>

                <?php
                    //$images = Helpers::getmultipleimage('section_4_88');
                ?>

                <div class="row">
                    <div class="col-md-4">
                        <div class="post-prev-img">
                            <a href="/frontend/images/certificate-02.jpg" class="lightbox-gallery-2 mfp-image"><img src="/frontend/images/certificate-02.jpg" alt="" /></a>
                        </div>
                    </div>

                    <div class="col-md-4 mt-xs-20">
                        <div class="post-prev-img">
                            <a href="/frontend/images/certificate-01.jpg" class="lightbox-gallery-2 mfp-image"><img src="/frontend/images/certificate-01.jpg" alt="" /></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="small-section bg-gray-lighter" id="expertsiniks">
            <div class="container relative">
                <div class="row d-flex align-items-center">
                    <div class="col-md-6">
                        <div class="inner-pad-02">
                            <div class="page-title color-blue mb-20 wow fadeInDown" data-wow-delay="0.3s" data-wow-duration="1s"><?php echo Helpers::getcontent("section_5_89"); ?></div>
                            <div class="section-text black">
                                <?php echo Helpers::getcontent("section_5_91"); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mt-xs-20s">
                        <div class="img-rounded">
                            <img src="<?php echo Helpers::getsingleimage('section_5_90'); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="small-section" id="authorsofbooks">
            <div class="container relative">
                <div class="row d-flex align-items-center">
                    <div class="col-md-6 xs-order-2 mt-xs-20">
                        <div class="img-rounded">
                            <img src="<?php echo Helpers::getsingleimage('section_6_93'); ?>">
                        </div>
                    </div>
                    <div class="col-md-6 xs-order-1">
                        <div class="inner-pad-01">
                            <div class="page-title color-blue mb-20 wow fadeInDown" data-wow-delay="0.3s" data-wow-duration="1s"><?php echo Helpers::getcontent("section_6_92"); ?></div>
                            <div class="section-text black">
                                <?php echo Helpers::getcontent("section_6_94"); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="small-section bg-gray-lighter" id="facultyforfdp">
            <div class="container relative">
                <div class="row mb-30">
                    <div class="col-md-12">
                        <h4 class="page-title mb-20 wow fadeInDown" data-wow-delay="0.3s" data-wow-duration="1s"><?php echo Helpers::getcontent("section_7_95"); ?></h4>
                        <div class="section-text black">
                            <?php echo Helpers::getcontent("section_7_97"); ?>

                        </div>
                    </div>
                </div>

                <h5 class="hs-line-3 mb-20">Images</h5>
                <div class="row">
                    <div class="col-6 col-md-3">
                        <div class="post-prev-img mb-30">
                            <a href="/frontend/images/program-01.jpg" class="lightbox-gallery-2 mfp-image"><img src="/frontend/images/program-01-thumb.jpg" alt="" /></a>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="post-prev-img mb-30">
                            <a href="/frontend/images/program-02.jpg" class="lightbox-gallery-2 mfp-image"><img src="/frontend/images/program-02-thumb.jpg" alt="" /></a>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="post-prev-img mb-30">
                            <a href="/frontend/images/program-03.jpg" class="lightbox-gallery-2 mfp-image"><img src="/frontend/images/program-03-thumb.jpg" alt="" /></a>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="post-prev-img mb-30">
                            <a href="/frontend/images/program-04.jpg" class="lightbox-gallery-2 mfp-image"><img src="/frontend/images/program-04-thumb.jpg" alt="" /></a>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="post-prev-img mb-30">
                            <a href="/frontend/images/program-05.jpg" class="lightbox-gallery-2 mfp-image"><img src="/frontend/images/program-05-thumb.jpg" alt="" /></a>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="post-prev-img mb-30">
                            <a href="/frontend/images/program-06.jpg" class="lightbox-gallery-2 mfp-image"><img src="/frontend/images/program-06-thumb.jpg" alt="" /></a>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="post-prev-img mb-30">
                            <a href="/frontend/images/program-07.jpg" class="lightbox-gallery-2 mfp-image"><img src="/frontend/images/program-07-thumb.jpg" alt="" /></a>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="post-prev-img mb-30">
                            <a href="/frontend/images/program-08.jpg" class="lightbox-gallery-2 mfp-image"><img src="/frontend/images/program-08-thumb.jpg" alt="" /></a>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="post-prev-img mb-30">
                            <a href="/frontend/images/program-09.jpg" class="lightbox-gallery-2 mfp-image"><img src="/frontend/images/program-09-thumb.jpg" alt="" /></a>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="post-prev-img mb-30">
                            <a href="/frontend/images/program-10.jpg" class="lightbox-gallery-2 mfp-image"><img src="/frontend/images/program-10-thumb.jpg" alt="" /></a>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="post-prev-img mb-30">
                            <a href="/frontend/images/program-11.jpg" class="lightbox-gallery-2 mfp-image"><img src="/frontend/images/program-11-thumb.jpg" alt="" /></a>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="post-prev-img mb-30">
                            <a href="/frontend/images/program-12.jpg" class="lightbox-gallery-2 mfp-image"><img src="/frontend/images/program-12-thumb.jpg" alt="" /></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\bgiks-frontend\resources\views/frontend/credentials.blade.php ENDPATH**/ ?>